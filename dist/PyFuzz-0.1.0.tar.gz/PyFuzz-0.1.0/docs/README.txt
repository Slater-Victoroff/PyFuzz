This is a set of methods that will allow you to very quickly fake a large number of different data types like text in various languages, and a number of image formats.
